#ifndef MRK_INC_H
#define MRK_INC_H

#include "vfonts/vector_chars.h"

XPoint **marker[] = {
	char840, char844, char866, char845, char847, char850, 
	char855, char834, 
};

int *marker_p[] = {
	char_p840, char_p844, char_p866, char_p845, char_p847, 
	char_p850, char_p855, char_p834, 
};

#endif /* MRK_INC_H */
