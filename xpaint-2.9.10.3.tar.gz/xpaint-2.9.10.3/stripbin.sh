#!/bin/sh
cd /usr/bin

if [ -x xpaint ] ;
then
  strip xpaint
  echo "stripping xpaint"
fi

if [ -x pdfconcat ] ;
then
  strip pdfconcat
  echo "stripping pdfconcat"
fi

if [ -x ppmtops ] ;
then
  strip ppmtops
  echo "stripping ppmtops"
fi

if [ -x pgf2pnm ] ;
then
  strip pgf2pnm
  echo "stripping pgf2pnm"
fi
