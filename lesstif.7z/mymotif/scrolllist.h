
#include <Xm/XmAll.h>
Widget create_scrolled_list(Widget );
 
