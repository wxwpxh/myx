
#include <Xm/XmAll.h> 

Widget create_edit_dialog(Widget );
 
