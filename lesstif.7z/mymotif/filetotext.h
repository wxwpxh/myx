
#include <stdlib.h>
#include  <stdio.h> 
#include <iostream>
using namespace std;
#include <Xm/XmAll.h>
void ReadFiletoXmtext(char *,Widget );
